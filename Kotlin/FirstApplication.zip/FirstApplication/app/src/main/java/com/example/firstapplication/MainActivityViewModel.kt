package com.example.firstapplication

import androidx.lifecycle.ViewModel

class MainActivityViewModel:ViewModel() {

    var bmi=0.0;

    fun changeBmi(bmi:Double){
        this.bmi=bmi;
    }
    var status="Enter Height and weight"
    fun changeStatus(status:String){
        this.status=status;
    }


}