package com.example.firstapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        val button=findViewById<Button>(R.id.button)
//        val userName=findViewById<EditText>(R.id.userName)
//        val userNameText=findViewById<TextView>(R.id.userNameText)
//
//        button.setOnClickListener{
//            val name=userName.text.toString()
//            if(name!=""){
//                userNameText.text="Hello $name!"
//                userName.text.clear()
//            }
//            else {
//                    val toast= Toast.makeText(applicationContext,"Please Enter Name",Toast.LENGTH_SHORT)
//                    toast.show()
    //                    }


        val heightInput=findViewById<EditText>(R.id.heightInput)
        val weightInput=findViewById<EditText>(R.id.weightInput)
        val bmiButton=findViewById<Button>(R.id.bmiButton)
        val bmiView=findViewById<TextView>(R.id.bmiView)
        val bmiView1=findViewById<TextView>(R.id.bmiView1)
        val cl=findViewById<ConstraintLayout>(R.id.cl)

       var mainActivityViewModel:MainActivityViewModel= ViewModelProvider(this).get(MainActivityViewModel::class.java)
        bmiView.text=mainActivityViewModel.bmi.toInt().toString()

        bmiView.text=mainActivityViewModel.status.toString()

        bmiButton.setOnClickListener{


            var height=heightInput.text.toString()
            var weight=weightInput.text.toString()



            if(height!="" && weight!="") {
                var resHeight = height.toDouble() / 100
                var result = (weight.toDouble() / (resHeight * resHeight))
                mainActivityViewModel.changeBmi(result);
                bmiView.text = result.toString();

                var status:String=""
                when{

                    result<18.5->{
                        status="UnderWeight"
                    }
                    result>=18.5 && result<25->{
                        status="Normal"
                    }
                    result>=25 && result<30->{
                        status="OverWeight"
                    }
                    else->{
                        status="Obesity"
                    }

                }
                mainActivityViewModel.changeStatus(status);
                bmiView1.text=status.toString()

            }
            else{

                val snackBar= Snackbar.make(cl, "Enter Inputs",Snackbar.LENGTH_LONG)
                snackBar.show()

            }
        }

    }
}