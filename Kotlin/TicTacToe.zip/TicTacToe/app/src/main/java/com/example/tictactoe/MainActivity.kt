package com.example.tictactoe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var btn1 = findViewById<Button>(R.id.btn1)
        var btn2 = findViewById<Button>(R.id.btn2)
        var btn3 = findViewById<Button>(R.id.btn3)
        var btn4 = findViewById<Button>(R.id.btn4)
        var btn5 = findViewById<Button>(R.id.btn5)
        var btn6 = findViewById<Button>(R.id.btn6)
        var btn7 = findViewById<Button>(R.id.btn7)
        var btn8 = findViewById<Button>(R.id.btn8)
        var btn9 = findViewById<Button>(R.id.btn9)
        var play = findViewById<Button>(R.id.play)
        var winner = findViewById<TextView>(R.id.winner)

        var arr = arrayOf<String>()

        var count = 0;


        fun playGame() {


             arr = arrayOf<String>("1", "2", "3", "4", "5", "6", "7", "8", "9")

            fun winner() {



                if ((arr[0] == arr[1]) && (arr[1] == arr[2]) ||
                    (arr[0] == arr[3]) && (arr[3] == arr[6]) ||
                    (arr[1] == arr[4]) && (arr[4] == arr[7]) ||
                    (arr[3] == arr[4]) && (arr[4] == arr[5]) ||
                    (arr[6] == arr[7]) && (arr[7] == arr[8]) ||
                    (arr[2] == arr[5]) && (arr[5] == arr[8]) ||
                    (arr[0] == arr[4]) && (arr[4] == arr[8]) ||
                    (arr[2] == arr[4]) && (arr[4] == arr[6])
                ) {

                    if (count % 2 == 0) {
                        winner.text = "Player 2 Wins"
                    } else {
                        winner.text = "Player 1 Wins"
                    }
                }
                else if(count>=9 && arr[8]!=""){
                    winner.text="No One Wins"
                }
            }





            btn1.setOnClickListener {

                if (count % 2 == 0) {
                    btn1.text = "x"
                    arr[0] = "x"
                    count++
                } else {
                    btn1.text = "0"
                    arr[0] = "0"
                    count++
                }

                winner()

            }

            btn2.setOnClickListener {

                if (count % 2 == 0) {
                    btn2.text = "x"
                    arr[1] = "x"
                    count++
                } else {
                    btn2.text = "0"
                    arr[1] = "0"
                    count++
                }
                winner()

            }

            btn3.setOnClickListener {

                if (count % 2 == 0) {
                    btn3.text = "x"
                    arr[2] = "x"
                    count++
                } else {
                    btn3.text = "0"
                    arr[2] = "0"
                    count++
                }
                winner()
            }

            btn4.setOnClickListener {

                if (count % 2 == 0) {
                    btn4.text = "x"
                    arr[3] = "x"
                    count++
                } else {
                    btn4.text = "0"
                    arr[3] = "0"
                    count++
                }
                winner()
            }

            btn5.setOnClickListener {

                if (count % 2 == 0) {
                    btn5.text = "x"
                    arr[4] = "x"

                    count++
                } else {
                    btn5.text = "0"
                    arr[4] = "0"

                    count++
                }
                winner()
            }

            btn6.setOnClickListener {

                if (count % 2 == 0) {
                    btn6.text = "x"
                    arr[5] = "x"

                    count++
                } else {
                    btn6.text = "0"
                    arr[5] = "0"

                    count++
                }
                winner()

            }

            btn7.setOnClickListener {

                if (count % 2 == 0) {
                    btn7.text = "x"
                    arr[6] = "x"

                    count++
                } else {
                    btn7.text = "0"
                    arr[6] = "0"

                    count++
                }

                winner()

            }

            btn8.setOnClickListener {

                if (count % 2 == 0) {
                    btn8.text = "x"
                    arr[7] = "x"

                    count++
                } else {
                    btn8.text = "0"
                    arr[7] = "0"

                    count++
                }
                winner()
            }

            btn9.setOnClickListener {

                if (count % 2 == 0) {
                    btn9.text = "x"
                    arr[8] = "x"

                    count++
                } else {
                    btn9.text = "0"
                    arr[8] = "0"

                    count++
                }
                winner()

            }

        }
        playGame()
        play.setOnClickListener {

//            var arr = arrayOf<String>("1", "2", "3", "4", "5", "6", "7", "8", "9")
            btn1.text = " "
            btn2.text = " "
            btn3.text = " "
            btn4.text = " "
            btn5.text = " "
            btn6.text = " "
            btn7.text = " "
            btn8.text = " "
            btn9.text = " "
            winner.text="Winner"
            count = 0
            playGame()
        }
    }
}
