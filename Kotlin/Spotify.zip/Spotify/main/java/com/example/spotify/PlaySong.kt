package com.example.spotify

import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.floatingactionbutton.FloatingActionButton

class PlaySong: AppCompatActivity(){


    lateinit var runnable: Runnable
    var handler= Handler()
    companion object {
        var mediaPlayer: MediaPlayer? = null
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.playsong)


        val songData:SongData= ViewModelProvider(this).get(SongData::class.java)
        var id=intent.getStringExtra("songId")!!.toInt()
        var song:Song=songData.songs.get(0)
        var index=0
        for(i in 0 until songData.songs.size){
            if(songData.songs.get(i).songId==id)
            {
                song=songData.songs.get(i)
                index=i
            }
        }



        val singleThumbnail=findViewById<ImageView>(R.id.singleThumbnail)
        val singleTitle=findViewById<TextView>(R.id.singleTitle)
        val singleArtist=findViewById<TextView>(R.id.singleArtist)
        val playSong=findViewById<FloatingActionButton>(R.id.playSong)
        val seekbar=findViewById<SeekBar>(R.id.seekBar)
        val currentTime=findViewById<TextView>(R.id.currentTime)
        val finalTime=findViewById<TextView>(R.id.finalTime)
        val prev=findViewById<FloatingActionButton>(R.id.prev)
        val next=findViewById<FloatingActionButton>(R.id.next)


        if(mediaPlayer!=null){
            mediaPlayer?.stop()
            mediaPlayer?.reset()
            mediaPlayer?.release()
            mediaPlayer=null
        }
        fun mainPlayer(song:Song){

            mediaPlayer=MediaPlayer.create(this,song.audio)
            mediaPlayer?.start()
            singleThumbnail.setImageResource(song.thumbnail)
            singleArtist.text=song.artistName
            singleTitle.text=song.songName

            playSong.setOnClickListener{

                if(!(mediaPlayer!!.isPlaying))
                {
                    mediaPlayer?.start()
                    playSong.setImageResource(R.drawable.ic_baseline_pause_24)
                }
                else
                {
                    mediaPlayer?.pause()
                    playSong.setImageResource(R.drawable.ic_baseline_play_arrow_24)
                }

            }


            seekbar.progress=0
            seekbar.max=mediaPlayer!!.duration


            seekbar.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
                override fun onProgressChanged(p0: SeekBar?, progress: Int, fromuser: Boolean) {

                    if(fromuser){
                        mediaPlayer!!.seekTo(progress)
                    }

                    var p1_sec=(progress/1000)
                    var min:Int=(p1_sec/60)
                    var sec:Int=(p1_sec%60)

                    currentTime.text=min.toString() + ":" + sec.toString()

                    var p2_sec=(seekbar.max/1000)
                    var min2:Int=(p2_sec/60)
                    var sec2:Int=(p2_sec%60)

                    finalTime.text= min2.toString()+":"+sec2.toString()

                }

                override fun onStartTrackingTouch(p0: SeekBar?) =Unit


                override fun onStopTrackingTouch(p0: SeekBar?)=Unit

            })

            runnable= Runnable {
                seekbar.progress = mediaPlayer!!.currentPosition
                handler.postDelayed(runnable, 1000)
            }

            handler.postDelayed(runnable,1000)

            mediaPlayer!!.setOnCompletionListener {
                mediaPlayer!!.pause()
                playSong.setBackgroundColor(R.drawable.ic_baseline_play_arrow_24)
            }
        }

        mainPlayer(song)

        prev.setOnClickListener{
            mediaPlayer?.stop()
            mediaPlayer?.release()

            if(index<=0){
                index=songData.songs.size-1
            }
            else{
                index--
            }
            song=songData.songs.get(index)
            mainPlayer(song)
        }

        next.setOnClickListener{
            mediaPlayer?.stop()
            mediaPlayer?.release()

            if(index>=songData.songs.size-1){
                index=0
            }
            else{
                index++
            }
            song=songData.songs.get(index)
            mainPlayer(song)
        }


    }

}





