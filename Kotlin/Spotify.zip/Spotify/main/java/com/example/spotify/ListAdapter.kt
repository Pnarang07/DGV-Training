package com.example.spotify

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.core.graphics.drawable.toDrawable
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ListAdapter(val context: Context, val items:List<Song>) : RecyclerView.Adapter<ListAdapter.ViewHolder>(){


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(context).inflate(R.layout.listitem,parent,false)
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val itemData=items.get(position)

        holder.songName.text=itemData.songName
        holder.artistName.text=itemData.artistName
        holder.image.setImageResource(itemData.thumbnail)

        holder.button.setOnClickListener{

            val intent= Intent(context,PlaySong::class.java)
            intent.putExtra("songId",itemData.songId.toString())
            context.startActivity(intent)
        }

    }


    override fun getItemCount(): Int {
        return items.size;
    }


    class ViewHolder(view: View):RecyclerView.ViewHolder(view){


        var songName=view.findViewById<TextView>(R.id.songName)
        var artistName=view.findViewById<TextView>(R.id.artistName)
        var image=view.findViewById<ImageView>(R.id.image)
        var button=view.findViewById<FloatingActionButton>(R.id.button)


    }


}