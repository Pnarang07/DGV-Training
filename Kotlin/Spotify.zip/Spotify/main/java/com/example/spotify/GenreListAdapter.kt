package com.example.spotify

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class GenreListAdapter(val context: Context,val items:List<String>)  : RecyclerView.Adapter<GenreListAdapter.ViewHolder>() {
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):ViewHolder {
        return ViewHolder(
            LayoutInflater.from(context).inflate(R.layout.list_song_genre, parent, false)
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val itemData=items.get(position)
        holder.songGenre.text=itemData
        holder.songGenre.setOnClickListener{
            val intent= Intent(context,MainActivity::class.java)
            intent.putExtra("category",itemData)
            context.startActivity(intent)
        }
    }
    
    override fun getItemCount(): Int {
        return items.size;
    }
    
    class ViewHolder(view: View):RecyclerView.ViewHolder(view){
        var songGenre=view.findViewById<TextView>(R.id.songGenre)
    }
}