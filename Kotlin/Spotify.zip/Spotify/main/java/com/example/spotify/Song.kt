package com.example.spotify

    class Song(songName:String,artistName:String,thumbnail:Int,audio:Int,category:String,songId:Int) {

        var songName:String=""
        var artistName:String=""
        var thumbnail:Int=0
        var audio:Int
        var category:String=" "
        var songId:Int=0

        init {
            this.songName=songName
            this.artistName=artistName
            this.thumbnail=thumbnail
            this.audio=audio
            this.category=category
            this.songId=songId
        }


    }
