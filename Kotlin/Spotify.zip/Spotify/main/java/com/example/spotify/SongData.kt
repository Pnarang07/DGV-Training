package com.example.spotify

import androidx.lifecycle.ViewModel

class SongData:ViewModel() {

    var songs= listOf<Song>(
        Song("Paris Ka Trip","Milind and YOYO",R.drawable.pariskatrip,R.raw.pariskatrip,"Punjabi",1),
        Song("Chaand Baaliyan","Aditya",R.drawable.chandballiyan,R.raw.chaandbaaliyan,"Hindi",2),
        Song("Game Over","Karan Aujla",R.drawable.gameover,R.raw.gameover,"Punjabi",3),
        Song("Goat","Sidhu Moosewala",R.drawable.goat,R.raw.goat,"Punjabi",4),
        Song("I Guess","Krsna",R.drawable.iguess,R.raw.iguess,"Rap",5),
        Song("Rinki Ke Papa","Manoj Tiwari",R.drawable.rinkikepapa,R.raw.rikikepapa,"Hindi",6),
        Song("Us","Sidhu Moosewalla",R.drawable.us,R.raw.us,"Punjabi",7),
        Song("Oops","King",R.drawable.ops,R.raw.ops,"Rap",8),
        Song("Rattan Lambiyan","Jubin",R.drawable.rl,R.raw.rl,"Hindi",9),
        Song("Dil Galti","Jubin",R.drawable.dil,R.raw.dil,"Hindi",10)

    )

    var songcategory= listOf<String>("Punjabi","Hindi","Rap")

}