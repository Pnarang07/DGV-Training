package com.example.spotify

import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        setContentView(R.layout.activity_main)

        var rcl=findViewById<RecyclerView>(R.id.rcl)
        val songData:SongData=ViewModelProvider(this).get(SongData::class.java)

        var category=intent.getStringExtra("category")

        val list= mutableListOf<Song>()

        for(i in 0 until songData.songs.size){
            if(songData.songs.get(i).category==category){
                list.add(songData.songs.get(i))
            }
        }

        rcl.layoutManager = LinearLayoutManager(this)
        rcl.adapter = ListAdapter(this,list)


    }
}