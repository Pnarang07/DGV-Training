package com.example.spotify

import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton


class SongGenreMain : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        setContentView(R.layout.songgenre_main)

        var rcll=findViewById<RecyclerView>(R.id.rcll)

        var songData:SongData= ViewModelProvider(this).get(SongData::class.java)

        rcll.adapter = GenreListAdapter(this,songData.songcategory)


        var search=findViewById<FloatingActionButton>(R.id.search)
        var searchSong=findViewById<EditText>(R.id.searchSong)

        search.setOnClickListener{
            var list1= mutableListOf<Song>()
            for(i in 0 until songData.songs.size ){
                if(songData.songs.get(i).songName==searchSong.text.toString()){
                    list1.add(songData.songs[i])
                }
            }
            var listAdapter=ListAdapter(this,list1)
            rcll.adapter=listAdapter
        }

        rcll.layoutManager = LinearLayoutManager(this)


    }
}